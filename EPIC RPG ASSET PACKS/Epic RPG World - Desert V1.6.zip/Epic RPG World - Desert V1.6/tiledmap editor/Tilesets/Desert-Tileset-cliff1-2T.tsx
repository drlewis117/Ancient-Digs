<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="platform-raw-2t" tilewidth="32" tileheight="32" tilecount="288" columns="16">
 <image source="../../tilesets/cliff1-2 tiles tall.png" width="512" height="576"/>
 <tile id="1" probability="0"/>
 <tile id="3" probability="0"/>
 <tile id="9" probability="0"/>
 <tile id="10" probability="0"/>
 <tile id="18" probability="0.1"/>
 <tile id="32">
  <objectgroup draworder="index" id="2">
   <object id="1" x="16" y="0.076555" width="16" height="32"/>
  </objectgroup>
 </tile>
 <tile id="33" probability="0.1"/>
 <tile id="35" probability="0.1"/>
 <tile id="48">
  <objectgroup draworder="index" id="2">
   <object id="1" x="16" y="0" width="16" height="32"/>
  </objectgroup>
 </tile>
 <tile id="50" probability="0.1"/>
 <tile id="64">
  <objectgroup draworder="index" id="2">
   <object id="1" x="16" y="0" width="16" height="24"/>
  </objectgroup>
 </tile>
 <tile id="65" probability="0"/>
 <tile id="67" probability="0"/>
 <tile id="80">
  <objectgroup draworder="index" id="2">
   <object id="1" x="16" y="0" width="16" height="12"/>
  </objectgroup>
 </tile>
 <tile id="144" probability="0"/>
 <tile id="145" probability="0"/>
 <tile id="146" probability="0"/>
 <tile id="147" probability="0"/>
 <tile id="148" probability="0"/>
 <tile id="149" probability="0"/>
 <tile id="151" probability="0"/>
 <tile id="152" probability="0"/>
 <tile id="153" probability="0"/>
 <tile id="154" probability="0"/>
 <tile id="155" probability="0"/>
 <tile id="156" probability="0"/>
 <tile id="176" probability="0"/>
 <tile id="177" probability="0"/>
 <tile id="178" probability="0"/>
 <tile id="179" probability="0"/>
 <tile id="180" probability="0"/>
 <tile id="192" probability="0"/>
 <tile id="193" probability="0"/>
 <tile id="194" probability="0"/>
 <tile id="195" probability="0"/>
 <tile id="196" probability="0"/>
 <tile id="197" probability="0"/>
 <tile id="198" probability="0"/>
 <tile id="199" probability="0"/>
 <tile id="200" probability="0"/>
 <tile id="201" probability="0"/>
 <tile id="202" probability="0"/>
 <tile id="203" probability="0"/>
 <tile id="204" probability="0"/>
 <tile id="208" probability="0"/>
 <tile id="209" probability="0"/>
 <tile id="210" probability="0"/>
 <tile id="211" probability="0"/>
 <tile id="212" probability="0"/>
 <tile id="224" probability="0"/>
 <tile id="225" probability="0"/>
 <tile id="226" probability="0"/>
 <tile id="227" probability="0"/>
 <tile id="228" probability="0"/>
 <wangsets>
  <wangset name="Cliff1-2T" type="corner" tile="66">
   <wangcolor name="" color="#ff0000" tile="66" probability="1"/>
   <wangtile tileid="1" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="2" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="3" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="16" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="17" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="18" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="19" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="20" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="25" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="26" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="32" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="33" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="34" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="35" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="36" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="48" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="49" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="50" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="51" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="52" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="65" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="66" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="67" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="128" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="129" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="130" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="131" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="132" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="133" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="134" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="135" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="136" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="137" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="144" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="145" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="146" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="147" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="148" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="149" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="151" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="152" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="153" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="154" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="155" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="156" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="192" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="193" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="194" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="195" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="196" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="197" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="198" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="199" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="200" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="201" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="202" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="203" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="204" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="208" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="209" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="210" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="211" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="212" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="224" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="225" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="226" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="227" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="228" wangid="0,0,0,1,0,1,0,0"/>
  </wangset>
 </wangsets>
</tileset>
