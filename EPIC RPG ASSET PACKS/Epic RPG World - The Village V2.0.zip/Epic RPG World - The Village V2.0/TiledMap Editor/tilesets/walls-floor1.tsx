<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="walls-floor1" tilewidth="32" tileheight="32" tilecount="4096" columns="64">
 <image source="../../buildings/walls-floor1.png" width="2048" height="2048"/>
</tileset>
